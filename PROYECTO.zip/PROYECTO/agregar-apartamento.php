<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  <center>
<div class="contenedor">
  <form method="POST" action="agregar-apartamento.php"> <br> <br> <br>
     <label>ID</label> <br>
    <input type="number" name="id"> 
    <br>

     <label>Numero De Apartamento</label> <br>
    <input type="number" name="apartamento">
    <br>

    <label>Torre</label> <br>
    <input type="text" name="torre">
    <br>

     <label>Estado</label> <br>
    <input type="text" name="estado"> 
    <br>

    <label>Numero De Personas</label> <br>
    <input type="number" name="personas"> 
    <br>

<br>
    <input type="submit" class="btn btn-primary" name="register"> 
    <a href="index-apartamento.php">Regresar</a>
  </form>
  <?php 
  require 'conexion.php';
    if (isset($_POST['register'])) {
      
      $id=$_POST['id'];
      $numeroA=$_POST['apartamento'];
      $numeroT=$_POST['torre'];
      $estado=$_POST['estado'];
      $personas=$_POST['personas'];
      

      $insertarDatos = "INSERT INTO tbl_apartamento VALUES ('$id','$numeroA','$numeroT','$estado','$personas')";
      $ejecutarInsertar = mysqli_query($con,$insertarDatos);
      if (!$ejecutarInsertar) {
        echo "Error en la linea de sql";
      }
    }
   ?>

</div> 
</center>
</body>
</html>  