<?php 
  include ("conexion.php");

 	$id=$_POST["id"];
   
    $resultado;

    
    mysqli_query($con,"DELETE from tbl_usuario2 where id='$id'") or die("error al eliminar los datos");

     mysqli_close($con);
      echo "Datos eliminados correctamente"; 
    
   ?>
     <a href="index.php">Regresar</a>