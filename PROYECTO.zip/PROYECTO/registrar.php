<?php
 require 'conexion.php';
  
 $nombre  = $_POST['name'];
 $email  = $_POST['email'];


$insertar = "INSERT INTO personas VALUES (NULL,'$documento','$nombres','$apellidos','$email','$telefono','$fecha','$genero','$tipo')";

$query = mysqli_query($con, $insertar);

if($query){

   echo "<script> alert('correcto');
    location.href = '../agregar.php';
   </script>";

}else{
    echo "<script> alert('incorrecto');
    location.href = '../agregar.php';
    </script>";
}
?>