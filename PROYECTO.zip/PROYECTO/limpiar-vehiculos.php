<?php 
  include ("conexion.php");

 	$placa=$_POST['placa'];
   
    $resultado;

    
    mysqli_query($con,"DELETE from tbl_vehiculos where placa_vehiculo='$placa'") or die("error al eliminar los datos");
     
     mysqli_close($con);
      echo "Datos eliminados correctamente"; 
    
   ?>
     <a href="index-vehiculos.php">Regresar</a>