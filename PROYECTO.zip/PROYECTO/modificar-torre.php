 <?php 
  include ("conexion.php");
   
 	$numeroT=$_POST["torre"];
	$numeroA=$_POST["apartamento"];
    $resultado;

    
     mysqli_query($con,"UPDATE tbl_torre SET numero_torre='$numeroT', numero_apartamento='numeroA' WHERE numero_torre='$numeroT'") or die("error al actualizar");

     mysqli_close($con);
      echo "Datos cargados correctamente";
   ?>
   <a href="index-torre.php">Regresar</a>