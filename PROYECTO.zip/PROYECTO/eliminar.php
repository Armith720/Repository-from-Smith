<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<title>Eliminar</title>
</head>
<body>
	<center> <br> <br> <br>
	<h3>ID de persona a eliminar</h3> 
	<form method="POST" action="limpiar.php"> <br>
		<label>ID</label> <br> 
    <input type="text" name="id" placeholder="Id del usuario"> <br> <br>
    <input type="submit" class="btn btn-danger" name="delete" value="Eliminar"> 

    <a href="index.php">Regresar</a>
  </form>
</center>
</body>
</html>