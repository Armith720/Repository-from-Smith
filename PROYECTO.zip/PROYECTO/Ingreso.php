<html></!DOCTYPE html>
<head>
<title> Formulario Login </title>

<link rel="stylesheet" href="">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body background="img/conjunto.jpg" >
<form method="POST" action = "Ingreso.php">
<Center> 
	<br> <br>
<label> <strong> INGRESO </strong> </label><br>
<label> <h4>Usuarios Registrados</h4> </label><br><br>
<Center>
<input type="text" placeholder="Usuario" name = Usuario> <br><BR>
<input type="password" placeholder="Contraseña" name= Contraseña> <br><BR>
<center>
<a href="Menu.php" class="btn btn-primary">Ingresar</a>
</center>
</form>
</body>
</html>