<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="img/fondito.jpeg"> 
  <title>Registro</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  <center>
<div class="contenedor">
  <form method="POST" action="agregar-vehiculos.php"> <br> <br> <br>
     <label>PLACA</label> <br>
    <input type="text" name="placa"> 
    <br>

     <label>TIPO DE VEHICULO</label> <br>
    <input type="text" name="tipo">
    <br>

    <label>COLOR</label> <br>
    <input type="text" name="color">
    <br>

<br>
    <input type="submit" class="btn btn-primary" name="register"> 
    <a href="index-vehiculos.php">Regresar</a>
  </form>
  <?php 
  require 'conexion.php';
    if (isset($_POST['register'])) {
      
      $placaV=$_POST['placa'];
      $tipoV=$_POST['tipo'];
      $colorV=$_POST['color'];
      

      $insertarDatos = "INSERT INTO tbl_vehiculos VALUES('$placaV','$tipoV','$colorV')";
      $ejecutarInsertar = mysqli_query($con,$insertarDatos);
      if (!$ejecutarInsertar) {
        echo "Error en la linea de sql";
      }
    }
   ?>

</div> 
</center>
</body>
</html>  