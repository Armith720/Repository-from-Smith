<?php
 require 'conexion.php';
  
 $numerotorre  = $_POST['torre'];
 $numeroapart = $_POST['apartamento'];


$insertar = "INSERT INTO personas VALUES ($numerotorre,'$numeroapart')";

$query = mysqli_query($con, $insertar);

if($query){

   echo "<script> alert('correcto');
    location.href = '../agregar-torre.php';
   </script>";

}else{
    echo "<script> alert('incorrecto');
    location.href = '../agregar-torre.php';
    </script>";
}
?>