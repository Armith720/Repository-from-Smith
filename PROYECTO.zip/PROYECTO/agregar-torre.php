<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="img/fondito.jpeg"> 
  <title>Registro</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  <center>
<div class="contenedor">
  <form method="POST" action="agregar-torre.php"> <br><br><br>
     <label>Torre</label> <br>
    <input type="number" name="torre" placeholder="Numero de torre"> 
    <br>

     <label>Apartamento</label> <br>
    <input type="text" name="apartamento" placeholder="Numero de apartamento">
    <br>

<br>
    <input type="submit" class="btn btn-primary" name="register"> 
    <a href="index-torre.php">Regresar</a>
  </form>
  <?php 
  require 'conexion.php';
    if (isset($_POST['register'])) {
      
      $numerotorre=$_POST['torre'];
      $numeroapart=$_POST['apartamento'];
      

      $insertarDatos = "INSERT INTO tbl_torre VALUES('$numerotorre','$numeroapart')";
      $ejecutarInsertar = mysqli_query($con,$insertarDatos);
      if (!$ejecutarInsertar) {
        echo "Error en la linea de sql";
      }
    }
   ?>

</div> 
</center>
</body>
</html>  