 <?php 
  include ("conexion.php");

 	$Id=$_POST['id'];
	$Documento=$_POST['documento'];
	$Nombres=$_POST['nombres'];
	$Apellidos=$_POST['apellidos'];
	$Email=$_POST['email'];
	$Telefono=$_POST['telefono'];
	$Fecha=$_POST['fecha'];
	$Genero=$_POST['genero'];
	$TipoUsuario=$_POST['tipo'];
    $resultado;

    
    mysqli_query($con,"UPDATE tbl_usuario2 SET nombres='$Nombres', apellidos='$Apellidos', email='$Email', telefono= '$Telefono', fechaIngreso='$Fecha', genero= '$Genero', tipoUsuario= '$TipoUsuario' WHERE id='$Id'") or die("error al actualizar");

     mysqli_close($con);
      echo "Datos cargados correctamente";
   ?>
   <a href="index.php">Regresar</a>