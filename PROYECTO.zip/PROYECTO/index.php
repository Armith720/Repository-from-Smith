<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>

	<div>
		<a href="agregar.php"><button type="button" class="btn-primary"> Nuevo </button></a> 
		<a href="Menu.php"><button style="margin-left:91%" type="button"class="btn-danger"> Salir </button></a> 
	    <?php 

	    $inc=include ("conexion.php");

		if ($inc){

			$consulta= "SELECT * FROM tbl_usuario2"; 
			$resultado=mysqli_query($con,$consulta);
			   
			if ($resultado) { ?>

				<table class="table ">
					<thead class="thead-dark">
						<tr>
							<th>ID</th>
							<th>DOCUMENTO</th>
							<th>NOMBRES</th>
							<th>APELLIDOS</th>
							<th>EMAIL</th>
							<th>TELEFONO</th>
							<th>FECHA DE INGRESO</th>
							<th>GENERO</th>
						    <th>TIPO DE USUARIO</th>
						    <th></th>
				<?php  
				
				while ($fila=$resultado -> fetch_assoc()) {
								$Id=$fila['id'];
								$Documento=$fila['documento'];
								$Nombres=$fila['nombres'];
								$Apellidos=$fila['apellidos'];
								$Email=$fila['email'];
								$Telefono=$fila['telefono'];
								$Fecha=$fila['fechaIngreso'];
								$Genero=$fila['genero'];
								$TipoUsuario=$fila['tipoUsuario'];
						?>
						<tr>
							<td><?php echo $Id?></td>
							<td><?php echo $Documento?></td>
							<td><?php echo $Nombres?></td>
							<td><?php echo $Apellidos?></td>
							<td><?php echo $Email?></td>	
							<td><?php echo $Telefono?></td>
							<td><?php echo $Fecha?></td>
							<td><?php echo $Genero?></td>
							<td><?php echo $TipoUsuario?></td>
							<td>
								<a href="Editar.php"><button type="button" class="btn btn-dark">Editar</button></a>  <br>
								<a href="Eliminar.php"><button type="button" class="btn btn-danger">Eliminar</button></a>
								
							</td>
						</tr>

						
						<?php
					}
				} else {
					echo "no conecta";
				}
			} 
						?>					
					</tbody>
				</table>
		</div>	
	</body>
	</html>
</body>
</html>