<!DOCTYPE html>
<html>
<head>
	<title>Registro De Torres</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  
	<div>
		<a href="agregar-vehiculos.php"><button type="button" class="btn-primary">Nuevo</button></a> 
		<a href="Menu.php"><button style="margin-left:91%" type="button"class="btn-danger"> Salir </button></a>   

	    <?php 

	    $inc=include ("conexion.php");

		if ($inc){

			$consulta= "SELECT * FROM tbl_vehiculos"; 
			$resultado=mysqli_query($con,$consulta);
			   
			if ($resultado) { ?>

				<table class="table">
					<thead class="thead-dark">
						<tr>
							<th>PLACA</th>
							<th>TIPO DE VEHICULO</th>
							<th>COLOR</th>
							<th></th>
							
				<?php  
				
				while ($fila=$resultado -> fetch_assoc()) {
								$placa=$fila['placa_vehiculo'];
								$tipo=$fila['tipo_vehiculo'];
								$color=$fila['color_vehiculo'];
								
					?> 
					<tr>
						<td><?php echo $placa?></td>
						<td><?php echo $tipo?></td>
						<td><?php echo $color?></td>
					    <td>
								<a href="editar-vehiculos.php"><button type="button" class="btn btn-dark">Editar</button></a>
								<a href="eliminar-vehiculos.php"><button type="button" class="btn btn-danger">Eliminar</button></a>
								
								
							</td>
							
					</tr>
						
					<?php
				}
			} else {
					echo "no connasjkfa";
			}
		} 
						?>					
					</tbody>
				</table>
		</div>	
	</body>
	</html>
</body>
</html>