<!DOCTYPE html>
<html>
<head>
	<title>Registro De Torres</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  
	<div>
		<a href="agregar-torre.php"><button type="button" class="btn-primary">Nuevo</button></a> 
		<a href="Menu.php"><button style="margin-left:91%" type="button"class="btn-danger"> Salir </button></a>   

	    <?php 

	    $inc=include ("conexion.php");

		if ($inc){

			$consulta= "SELECT * FROM tbl_torre"; 
			$resultado=mysqli_query($con,$consulta);
			   
			if ($resultado) { ?>

				<table class="table ">
					<thead class="thead-dark">
						<tr>
							<th>NUMERO DE TORRE</th>
							<th>NUMERO DE APARTAMENTO</th>
							<th></th>
				<?php  
				
				while ($fila=$resultado -> fetch_assoc()) {
								$numerotorre=$fila['numero_torre'];
								$numeroapart=$fila['numero_apartamento'];
								
					?> 
					<tr>
						<td><?php echo $numerotorre?></td>
						<td><?php echo $numeroapart?></td>
					    <td>
								<a href="Editar.php"><button type="button" class="btn btn-dark">Editar</button></a>
								<a href="Eliminar.php"><button type="button" class="btn btn-danger">Eliminar</button></a>
								
								
							</td>
							
					</tr>
						
					<?php
				}
			} else {
					echo "no connasjkfa";
			}
		} 
						?>					
					</tbody>
				</table>
		</div>	
	</body>
	</html>
</body>
</html>