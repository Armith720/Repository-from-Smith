<html></!DOCTYPE html>
<head>
<title> Menú Principal </title> <br>
<link rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>

<body background="img/conjunto.jpg">
<form method="POST" action = "Menu.php">
<Center> <br>
<label> <u><h4> Menú Principal </h4><u> </label><br>
<Center> <br>
<a href="index.php" style= "" class ="btn btn-primary"> Usuarios </a> <br> <br>
<a href="index-torre.php" class ="btn btn-primary"> Torres </a> <br> <br>
<a href="index-apartamento.php" class ="btn btn-primary"> Apartamentos </a> <br> <br>
<a href="index-vehiculos.php" class ="btn btn-primary"> vehiculos </a> <br> <br>

<a href="ingreso.php" class ="btn btn-danger"> Salir </a>
</form>
</body>
</html>