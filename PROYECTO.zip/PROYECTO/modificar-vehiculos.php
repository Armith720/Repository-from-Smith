<?php 
  include ("conexion.php");
   
    $placaV=$_POST['placa'];
    $tipoV=$_POST['tipo'];
    $colorV=$_POST['color'];
    $resultado;

    
     mysqli_query($con,"UPDATE tbl_vehiculos SET placa_vehiculo='$placaV', tipo_vehiculo='$tipoV', color_vehiculo='$colorV' WHERE placa_vehiculo='$placaV'") or die("error al actualizar");

     mysqli_close($con);
      echo "Datos cargados correctamente";
   ?>
   <a href="index-vehiculos.php">Regresar</a>