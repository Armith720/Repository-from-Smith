<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Modificar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
    <center>
	<form method="POST" action="modificar.php"> 
     <label>Id</label> <br>
    <input type="number" name="id" placeholder="Id"> 
    <br>

     <label>Documento</label> <br>
    <input type="text" name="documento" placeholder="Documento">
    <br>

     <label>Nombres</label> <br>
    <input type="text" name="nombres" placeholder="Nombre">
    <br>

    <label>Apellidos</label> <br>
    <input type="text" name="apellidos" placeholder="Apellidos">
    <br>

     <label>Email</label> <br>
    <input type="text" name="email" placeholder="Ejemplo@gmail.com"> <br>
    <br>

    <label>Teléfono</label> <br>
    <input type="number" name="telefono" placeholder="Numero Telefonico">
    <br> 

    <label>Fecha De Ingreso</label> <br>
    <input type="date" name="fecha" placeholder="Día/Mes/Año">
    <br>

    <label>Genero</label> <br>
    <input type="text" name="genero" placeholder="Masculino/Femenino">
    <br>

    <label>Tipo De Usuario</label> <br>
    <input type="text" name="tipo" placeholder="Arrentatario/Propietario">
    <br> <br>
    <input type="submit" class="btn btn-primary" name="update" value="Actualizar"> 

    <a href="index.php">Regresar</a>
  </form>
 </center>
</body>
</html>