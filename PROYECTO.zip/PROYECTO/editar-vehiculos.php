<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Modificar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
    <center>
	<form method="POST" action="modificar-vehiculos.php"><br> <br> <br>
		<label>PLACA</label> <br>
    <input type="text" name="placa"> <br>
    <br>
    <label>TIPO DE VEHICULO</label> <br>
    <input type="text" name="tipo"> <br>
    <br>

    <label>COLOR</label> <br>
    <input type="text" name="color"> <br>
    <br>
    
    <br>
    <input type="submit" class="btn btn-primary" name="update" value="Actualizar"> 
    <a href="index-vehiculos.php">Regresar</a>
  </form>
 </center>
</body>
</html>