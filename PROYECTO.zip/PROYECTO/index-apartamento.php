<!DOCTYPE html>
<html>
<head>
	<title>Registro De Torres</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
  
	<div>
		<a href="agregar-apartamento.php"><button type="button" class="btn-primary">Nuevo</button></a> 
		<a href="Menu.php"><button style="margin-left:91%" type="button"class="btn-danger"> Salir </button></a>   

	    <?php 

	    $inc=include ("conexion.php");

		if ($inc){

			$consulta= "SELECT * FROM tbl_apartamento"; 
			$resultado=mysqli_query($con,$consulta);
			   
			if ($resultado) { ?>

				<table class="table ">
					<thead class="thead-dark">
						<tr>
							<th>ID</th>
							<th>Numero De Apartamento</th>
							<th>Numero De Torre</th>
							<th>Estado Del Apartamento</th>
							<th>Numero De Personas</th>
							<th></th>
				<?php  
				
				while ($fila=$resultado -> fetch_assoc()) {
								$ID=$fila['id_usuario'];
								$numeroA=$fila['numero_apartamento'];
								$numeroT=$fila['numero_torre'];
								$estado=$fila['estado_apartamento'];
								$numeropersonas=$fila['numero_personas'];		
					?> 
					<tr>
						<td><?php echo $ID?></td>
						<td><?php echo $numeroA?></td>
						<td><?php echo $numeroT?></td>
						<td><?php echo $estado?></td>
						<td><?php echo $numeropersonas?></td>
					    <td>
								<a href="editar-apartamento.php"><button type="button" class="btn btn-dark">Editar</button></a>
								<a href="eliminar-apartamento.php"><button type="button" class="btn btn-danger">Eliminar</button></a>
							</td>
							
					</tr>
						
					<?php
				}
			} else {
					echo "no connasjkfa";
			}
		} 
						?>					
					</tbody>
				</table>
		</div>	
	</body>
	</html>
</body>
</html>