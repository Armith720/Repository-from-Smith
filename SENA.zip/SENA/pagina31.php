<html>
<head>
	<title>Pagina 31</title>
</head>
<body>
<?php 
$conexion=mysqli_connect("localhost","root","","base1")or die("Problemas con la conexion"); 

$registros=mysqli_query($conexion,"select codigo from tbl_alumnos where mail='$_REQUEST[mail]'") or 

die("Problemas en el select:".mysqli_error($conexion));
if ($reg=mysqli_fetch_array($registros))
{
	mysqli_query($conexion,"delete from tbl_alumnos where mail='$_REQUEST[mail]'") or 
	die("Problemas en el select:".mysqli_error($conexion));
	echo "Se efectuo el borrado del alumno con dicho mail.";
}
else
{
	echo "No existe un alumno con ese mail.";
}
mysqli_close($conexion);
?>

</body>
</html>