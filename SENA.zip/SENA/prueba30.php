<html>
<head>
	<title>Prueba 30</title>
</head>
<body>
<form action="pagina30.php" method="post">
	Ingrese el mail del alumno a consultar:
<input type="text" name="mail">
<br>
<input type="submit" value="buscar">
</form>
</body>
</html>