<html>
 <head>
 <title>Captura de datos del form</title>
 </head>
 <body>
    <?php
       echo "El nombre ingresado es: ";
       echo $_REQUEST['nombre'];
    ?>
    <br>
    <a href="prueba12.html" type="button">Regrsar</a>
</body>
</html>