<html>
 <head>
 <title>Captura de datos del form</title>
 </head>
 <body>
    <?php
       echo "El nombre ingresado es: ";
       echo $_REQUEST['nombre'];

       echo "<br>";

       echo "La edad ingresada es: ";
       echo $_REQUEST['edad'];


       if ($_REQUEST>=18) {
       	echo " (Mayor de edad)";
       } else {
       	if ($_REQUEST['edad']<=17) {
       		echo " (Menor de edad)";
       	}
       }
    ?>
    <br>
    <a href="prueba13.html" type="button">Regrsar</a>
</body>
</html>