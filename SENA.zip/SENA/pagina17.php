<html>
<head></head>
<title>pagina7</title>
<body>
<?php

	$contador = 0;

	if (isset($_REQUEST['check1'])) {

		$contador++;
	}

	if (isset($_REQUEST['check2'])) {

		$contador++;
	}

	if (isset($_REQUEST['check3'])) {

		$contador++;
	}

	if (isset($_REQUEST['check4'])) {

		$contador++;
	}

	echo "A " .$_REQUEST['nombre']. " Le gustan " .$contador. " Deportes "
?>
<br>
<a href="prueba17.html">Regresar</a>
</body>
</html>