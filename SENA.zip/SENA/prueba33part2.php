<html>
<head>
	<title>Prueba 33 parte 2</title>
</head>
<body>
<?php 

$conexion=mysqli_connect("localhost","root","","base1") or 
   die("Problemas en la conexion");

$registros=mysqli_query($conexion,"update tbl_alumnos set codigocurso=$_REQUEST[codigocurso]where mail='$_REQUEST[mailviejo]'") or 

die("Problemas en el select:".mysqli_error($conexion));
echo "El curso fue modificado con exito";
?>
</body>
</html>