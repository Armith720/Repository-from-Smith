<html>
<head>
	<title>Pagina 32</title>
</head>
<body>
<?php 
$conexion=mysqli_connect("localhost","root","","base1") or 
 die("Problemas con la conexion");

mysqli_query($conexion,"delete from tbl_alumnos") or
die("Problemas en el select:".mysqli_error($conexion));
echo "Se efectuo el borrado de todos los alumnos.";

mysqli_close($conexion);
?>
</body>
</html>