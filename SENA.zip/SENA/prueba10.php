<!DOCTYPE html>
<html>
<head>
	<title>Prueba 10</title>
</head>
<body>
	<?php
	$valor=rand(1,100);
	$inicio=1;


	echo "El numero aleatorio es $valor<br><br>";

	while ($inicio<=$valor) {
		
		echo $inicio;

		echo "<br>";

	    $inicio++;
	}
	?>
</body>
</html>