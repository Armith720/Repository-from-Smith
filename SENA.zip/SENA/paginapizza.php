<!DOCTYPE html>
<html>
<head>
	<title>Pizza</title>
</head>
<body>
	<?php
	$ar=fopen("pedidos.txt", "a") or 
	die("Problemas de creacion");

	fputs($ar, "-> Cliente" .$_REQUEST["nombre"]);

	fputs($ar, "\n");
	fputs($ar, "- Direccion: " .$_REQUEST["direccion"]);

	if (insset($_REQUEST['check1'])) {
		 fputs($ar,"\n");
		 fputs($ar,"Mexicana: " .$_REQUEST["can_mex"]);
	}

	if (insset($_REQUEST['check2'])) {
		 fputs($ar,"\n");
		 fputs($ar,"Mozzarella: " .$_REQUEST["can_moz"]);

	if (insset($_REQUEST['check3'])) {
		 fputs($ar,"\n");
		 fputs($ar,"Napolitana: " .$_REQUEST["can_napo"]);
	?>



</body>
</html>