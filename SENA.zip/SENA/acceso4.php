<!DOCTYPE html>
<html>
<head>
	<title>Conexion con base1</title>
</head>
<body>
	<?php
	$conexion=mysqli_connect("localhost","root","","base1") or 
	    die("problemas con la conexion");


	    $registros = mysqli_query($conexion, "select codigo_alu,correo_alu,codigo_cur_alu from alumnos where nombre_alu='$_REQUEST[name]'") or die("problemas en el select ".mysqli_error($conexion));


	    if($reg=mysqli_fetch_array($registros)) {
	    	echo "Correo: ".$reg['correo_alu']. "<br>";
	    	echo "Curso: ";

	    	switch ($reg['codigo_cur_alu']) {
	    		case 1: echo "Java";
	    			break;
	    		case 2: echo "JS";
	    			break;
	    		case 3: echo "Python";
	    			break;
	    	}
	    	echo "<br>";
	    	echo "<br>";
	    } else {
	    	echo "No se encuentra ningun estudiante con ese nombre <br><br>";
	    }

	    mysqli_close($conexion);
	?>

	<a href="accesobase4.html">Regresar</a>

</body>
</html>