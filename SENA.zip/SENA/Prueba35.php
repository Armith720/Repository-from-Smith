<html>
<head>
	<title>	Prueba 35 </title>
</head>
<body>
<A href="pagina35.php?tabla=2">Tabla del 2</A> <br>

<A href="pagina35.php?tabla=3">Tabla del 3</A> <br>

<A href="pagina35.php?tabla=5">Tabla del 5</A> <br>

</body>
</html>