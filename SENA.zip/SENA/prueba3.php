<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php
	$num=rand(1,100);

	echo "El numero aleatorio ", $num;

	if ($num<50){
		echo  " Es menor que 50";
	} else {
		if ($num>50) {
			echo " Es mayor que 50";
		} else {
			if ($num=50) {
				echo "Es igual que 50";
			}
		}
	}

	?>

</body>
</html>