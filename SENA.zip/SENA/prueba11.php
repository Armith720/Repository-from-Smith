<!DOCTYPE html>
<html>
<head>
	<title>Prueba 11</title>
</head>
<body>

	<?php
    echo "Tabla del 2 (for)<br>";
	$f=0;
	for ($i=2; $i<=20; $i=$i+2) { 

		$f++;

		echo "<br>";

		echo "2 x " .$f. " = " .$i;
	}

	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>";


    echo "Tabla del 5 (while)<br><br>";
	$wi=1;
	while ($wi <= 10) {
		$resp=$wi*5;
		echo "5 x $wi = $resp <br>";
		$wi++;
	}

	?>
</body>
</html>