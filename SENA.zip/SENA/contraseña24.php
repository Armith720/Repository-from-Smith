<!DOCTYPE html>
<html>
<head>
	<title>Contraseña</title>
</head>
<body>
	<?php
	$login['usuario1']="Juanito";
	$login['contraseña1']="juan123";

	$login['usuario2']="Pepito";
	$login['contraseña2']="pepitoelvaliente";

	$login['usuario3']="Karol";
	$login['contraseña3']="kayuquima";

	echo "Usuario: " .$login['usuario3'];
	echo "<br>";
	echo "Contraseña: " .$login['contraseña3'];
	?>

</body>
</html>