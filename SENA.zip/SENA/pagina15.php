<html>
 <head>
 <title>Problema Suma y Resta</title>
 </head>
 <body>
    <?php

    echo $_REQUEST['name'];

    if ($_REQUEST['radio1']=="vago"){ 

       echo  " no tiene estudios";
    } else {  
      if ($_REQUEST['radio1']=="primaria") {
         echo " tiene estudios de primaria";
        } else {
         if ($_REQUEST['radio1']=="secundaria") {
           echo " tiene estudios de secundaria";
         }
        }
       }
    ?>
    <br>
    <a href="prueba15.html" type="button">Regrsar</a>
 </body>
 </html> 