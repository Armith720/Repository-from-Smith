<html>
<head>
	<title>Prueba 25</title>
</head>
<body>
<?php 
function mostrararticulo($men)
{
	echo "<h1 style=\"text-align:center\">";
	echo $men;
	echo "</h1>";
}

mostrararticulo("Primer titulo");
echo "<br>";
mostrararticulo("segundo titulo");
?>
</body>
</html>