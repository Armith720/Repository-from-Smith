<html>
 <head>
 <title>Problema Suma y Resta</title>
 </head>
 <body>
    <?php

       if ($_REQUEST['radio1']=="suma"){ 

           $suma=$_REQUEST['valor1'] + $_REQUEST['valor2'];
           echo "La suma es: ".$suma;
       } else {

         if ($_REQUEST['radio1']=="resta"){
             $resta=$_REQUEST['valor1'] - $_REQUEST['valor2'];
             echo "La resta es: ".$resta;
          }
        }
    ?>
    <br>
    <a href="prueba14.html" type="button">Regrsar</a>
 </body>
 </html>
