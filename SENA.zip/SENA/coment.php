<!DOCTYPE html>
<html>
<head>
	<title>coment</title> 
</head>
<body>
	<?php
	$ar=fopen("datos.txt", "a") or

	 die("Problemas en la creacion");
	 fputs($ar,$_REQUEST['name']);

	 fputs($ar," / ");
	 fputs($ar,$_REQUEST['comentarios']);

	 fputs($ar," / ");
	 echo "<br>";
	 fputs($ar,"/ ");
	 echo "<br>";
	 fclose($ar);


	 echo "Los datos se cargaron correctamente.";
	?>

	<a href="comentario.html">Regresar</a>
</body>
</html>