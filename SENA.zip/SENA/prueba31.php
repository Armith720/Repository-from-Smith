<html>
<head>
	<title></title>
</head>
<body>
<form action="pagina31.php" method="post">
	Ingrese el mail del alumno a borrar:
<input type="text" name="mail">
<br>
<input type="submit" value="buscar">
</form>
</body>
</html>