<html>
<head>
    <title>Problema</title>
</head>
<body>
   <?php
     echo "El nombre ingresado: ".$_REQUEST['nombre'];
     echo "<br>";
     echo "<br>";
     echo "El curriculum: ".$_REQUEST['curriculum'];
   ?>
   <br>
   <a href="prueba18.html">Regresar</a>
</body>
</html>