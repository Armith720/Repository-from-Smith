<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	$nombre="Jhonatan";
	$articulo="Mouse";
	$precio= 60.000;

	echo "Hola $nombre, su $articulo tiene un precio de $ $precio.";
	?>
</body>
</html>