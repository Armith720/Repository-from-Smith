<!DOCTYPE html>
<html>
<head>
	<title>Conexion con base1</title>
	
</head>
<body>
	<?php

	  $nota[0]=$_REQUEST['nota1'];
	  $nota[1]=$_REQUEST['nota2'];
	  $nota[2]=$_REQUEST['nota3'];



	
	

	    
	?>
	<a href="formulario1.html">Regresar</a>

</body>
</html>