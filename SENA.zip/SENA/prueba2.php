<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php
	  $dia=date("d");
	  if ($dia<=10){
	  	echo "Sitio activo";
	  }
	  else
	  {
	  	echo "Sitio fuera de servico";
	  }
	 ?>

</body>
</html>