<html>
<head>
	<title>Problema 37</title>
</head>
<body>
<form action="pagina37.php" method="post" enctype="multipart/form-data">
	Seleccione el archivo:

<input type="file" name="foto"><br>
<input type="submit" value="Enviar">
</form>
</body>
</html>