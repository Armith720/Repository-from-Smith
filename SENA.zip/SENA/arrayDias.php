<!DOCTYPE html>
<html>
<head>
	<title>Dias</title>
</head>
<body>
	<?php
	$dia[0] = "Lunes";
	$dia[1] = "Martes";
	$dia[2] = "Miercoles";
	$dia[3] = "Jueves";
	$dia[4] = "Viernes";
	$dia[5] = "Sabado";
	$dia[6] = "Domingo";


	echo "El primer dias es: ", $dia[0];
	echo "<br>";
	echo "El ultimo dias es: ", $dia[6];
	?>

</body>
</html>