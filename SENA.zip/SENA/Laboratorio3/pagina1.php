<html>

<head>
	<title>Ejercicio #1</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body background="img/charco.gif">
<div class="contenedor">
<center>
<div style="margin-top: 20px"> 
<?php

$conexion=mysqli_connect("localhost","root","","laboratorio3") or die("problemas con la conexion");
 
 $parcial1=$_REQUEST['parcial1'];
 $parcial2=$_REQUEST['parcial2'];
 $parcial3=$_REQUEST['parcial3'];
 $examenFinal=$_REQUEST['examenFinal'];
 $trabajoFinal=$_REQUEST['trabajoFinal'];
 $promedioParciales= ($parcial1 + $parcial2 + $parcial3)/3;

 echo "<br>La nota del parcial 1 es: ".$parcial1."<br><br>";
  echo "La nota del parcial 2 es: ".$parcial2."<br><br>";
  echo "La nota del parcial 3 es: ".$parcial3."<br><br>";
 echo "La nota del examen final es: ".$examenFinal."<br><br>";
 echo "La nota del trabajo final es: ".$trabajoFinal."<br><br>";

 $porcentajeParciales= $promedioParciales*0.35;
 $porcentajeExamen=$examenFinal*0.35;
 $porcentajeTrabajo=$trabajoFinal*0.30;
 $notaFinal=$porcentajeParciales+$porcentajeExamen+$porcentajeTrabajo;
 
 echo "La nota final es: ".$notaFinal."<br><br>";
 
 if($notaFinal>=3 and $notaFinal<5){  
  echo "El estudiante aprobó";
  }
 else if($notaFinal>0 and $notaFinal<3){
  echo "El estudiante no aprobó";
  }
  else{
  echo "El estudiante aprobó";
  }


mysqli_query($conexion, "insert into notas(parcia1,parcial2,parcial3,examen_final,trabajo_final,nota_final) values 
      ('$_REQUEST[parcial1]','$_REQUEST[parcial2]','$_REQUEST[parcial3]','$_REQUEST[examenFinal]','$_REQUEST[trabajoFinal]','$notaFinal')") or die("problemas en el select ".mysqli_error($conexion));

  mysqli_close($conexion);
?>
</div>
</center>
<br><br>
<a href="ejercicio1.html">Regresar</a>
</div>
</body>
</html>
