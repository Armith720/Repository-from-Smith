<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
	<title>Ejercicio #4</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="img/charco.gif">
	
<div class="hola" style="width: 700px;
  height: auto;
  margin-top: 150px;
  margin-right: 442px;
  margin-left: 305px;
  border-radius: 20px;
  overflow: hidden;
  

  background: rgb(105,258,225);
  background: linear-gradient(0deg, rgba(105,538,226,1) 0%, rgba(75,500,180,1) 100%);">

    <center>
    	<div style="margin-top: 40px">


    <?php
    $ar=fopen("datos2.txt", "a") or die("Problemas en la creacion");
    
        fputs($ar,$_REQUEST['ceduCli']);

        fputs($ar,"\n");
        fputs($ar,$_REQUEST['nombCli']);
        

        fputs($ar,"\n");
        fputs($ar,$_REQUEST['monCli']);

        fputs($ar,"\n");
        fputs($ar,$_REQUEST['tasaCli']);

        fputs($ar,"\n");
        fputs($ar,$_REQUEST['mesCli']);

        fputs($ar,"\n");
        echo "\n";
        fputs($ar,"\n");
        echo "\n";
        fclose($ar);
    ?>

	<?php 
	
	$valorCredito=$_REQUEST['monCli'];
	$tasaInteres=$_REQUEST['tasaCli'];
	$plazoMeses=$_REQUEST['mesCli'];

	$cuotaFija=$valorCredito*($tasaInteres*(1+$tasaInteres)**$plazoMeses)/((1+$tasaInteres)**$plazoMeses-1);

	$abonoInteres=$valorCredito*$tasaInteres;

	$abonoCapital=$cuotaFija-$abonoInteres;

	echo $_REQUEST['ceduCli']."<br>";
	echo $_REQUEST['nombCli']."<br>";
	
	?>
	<table border="3">
		<thead>
			<tr>
				<th>N°Cuota</th>
				<th>Saldo Anterior</th>
				<th>Valor Cuota Fija</th>
				<th>Abono Interes</th>
				<th>Abono Capital</th>
				<th>Nuevo Saldo</th>
			</tr>
		</thead>
		<?php 
		for ($i=1; $i <= $plazoMeses; $i++) { 
		?>
		<tbody>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo round($valorCredito); ?></td>
				<td><?php echo round($cuotaFija); ?></td>
				<td><?php echo round($abonoInteres); ?></td>
				<td><?php echo round($abonoCapital); ?></td>
				<td><?php $valorCredito=$valorCredito-$abonoCapital; echo round($valorCredito); ?></td>
			</tr>
		</tbody>
		<?php 
		$abonoInteres=$valorCredito*$tasaInteres;
		$abonoCapital=$cuotaFija-$abonoInteres;
		}
		?>
	</table>
	</div>
    </center><br>
	<a href="ejercicio4.html" style="margin-left: 320px;">Regresar</a>

</div>


</body>
</html>