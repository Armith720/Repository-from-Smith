<html>
<head>
    <title>Ejercicio #3</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="img/charco.gif">

  <div class="contenedor" style=" width: 442px;
  height: 200px;
  float: center;
  margin-top: 100px;
  margin-right: 442px;
  margin-left: 442px;
  border-radius: 20px;
  overflow: hidden;
  

  background: rgb(105,258,225);
  background: linear-gradient(0deg, rgba(105,538,226,1) 0%, rgba(75,500,180,1) 100%);"> 


    <div style="margin-top: 40px; margin-left: 20px">    
    <?php
     
     $nombre=$_POST['nombre'];
     $peso=$_POST['peso']; 
     $estatura=$_POST['estatura'];
     
     echo "El nombre del paciente es: ".$nombre."<br>";
      echo "El peso del paciente en kilogramos es: ".$peso."<br>";
      echo "La estatura del paciente en metros es:".$estatura."<br>";
     
     $IMC=$peso/($estatura*$estatura);
     echo "El indice de masa corporal del paciente es: ".$IMC."<br>";

     if($IMC<18.5){
      echo "El paciente esta por debajo del peso<br>";
     }
     else{
      if($IMC<24.9){
       echo "El paciente esta saludable<br>";
      }
      else{
       if($IMC<29.9){
        echo "El paciente esta con sobrepeso<br>";
       }
       else{
        if($IMC<39.9){
         echo "El paciente es obeso<br>";
        }
        else{
         echo "El paciente tiene obesidad morbida<br>";
        }
       }
      }
     } 


    $ar=fopen("datos.txt", "a") or die("Problemas en la creacion");
    
    fputs($ar,$_REQUEST['nombre']);

    fputs($ar,"\n");
    fputs($ar,$_REQUEST['peso']);

    fputs($ar,"\n");
    fputs($ar,$_REQUEST['estatura']);

    fputs($ar,"\n");
    echo "\n";
    fputs($ar,"\n");
    echo "\n";
    fclose($ar);


    echo "Los datos se cargaron correctamente.";
    ?>
    </div><br>
    <a href="ejercicio3.html">Regresar</a>
  </div>
</body>
</html>
