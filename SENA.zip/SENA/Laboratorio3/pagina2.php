<html>

<head>
    <title>Ejercicio #2</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body background="img/charco.gif">
<div class="ejercicio2">
<div style="margin-left: 52px">
<?php

$conexion=mysqli_connect("localhost","root","","laboratorio3") or die("problemas con la conexion");
 
    $nombre=$_REQUEST['nombre'];
    $cantidad=$_REQUEST['cantidad'];
    $precioTotal=$_REQUEST['precioTotal'];
      
    echo "<br><br>El nombre del vendedor es: ".$nombre."<br>";
    echo "La cantidad de automoviles vendidos es: ".$cantidad."<br>";
    echo "El precio total de automoviles vendidos es:".$precioTotal."<br>";
     
    $salarioBasico=737000;
    $comision=$cantidad*50000;
    $porcentajeVenta=$precioTotal*0.05;
    $salario=$salarioBasico+$comision+$porcentajeVenta;

    echo "El salario del vendedor es: ".$salario."<br>";



    mysqli_query($conexion, "insert into salario(vendedor,cantidad,precio) values 
      ('$_REQUEST[nombre]','$_REQUEST[cantidad]','$_REQUEST[precioTotal]')") or die("problemas en el select ".mysqli_error($conexion));

  mysqli_close($conexion);





 
?>
</div><br>
<a href="ejercicio2.html">Regresar</a>
</div>
</body>
</html>