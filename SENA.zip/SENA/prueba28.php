<html>
<head>
	<title>Prueba 28</title>
</head>
<body>
<h1>Alta de Alumnos</h1>
<form action="pagina28.php" method="post">
	Ingrese nombre: 
<br><input type="text" name="nombre"><br>
    Ingrese mail:
<br><input type="text" name="mail"><br>
    Seleccione el curso:
<select name="codigocurso">

<option value="1">JAVA</option>
<option value="2">HTML</option>
<option value="3">PHP</option>
</select>
<br>
<input type="submit" value="Registrar">
</form>


</body>
</html>