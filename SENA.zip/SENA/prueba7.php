<!DOCTYPE html>
<html>
<head>
	<title>Prueba 7</title>
</head>
<body>
	<?php
	$valor=rand(1,100);

	echo "El valor aleatorio  es $valor<br>";

	if ($valor<=9) {
		echo "El nuemro es de 1 digito";
	} else {
		if ($valor>=10 and $valor<=99) {
			echo "El nuemro es de 2 digitos";
		} else {
			if ($valor>=100) {
				echo "El numero es de 3 digitos";
			}
		}
	}
	?>
</body>
</html>