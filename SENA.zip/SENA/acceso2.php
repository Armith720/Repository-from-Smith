<!DOCTYPE html>
<html>
<head>
	<title>Conexion con base1</title>
</head>
<body>
	<?php
	$conexion=mysqli_connect("localhost","root","","base1") or 
	    die("problemas con la conexion");


	    $registros = mysqli_query($conexion, "select codigo_alu,nombre_alu,correo_alu,codigo_cur_alu from alumnos") or die("problemas en el select ".mysqli_error($conexion));


	    while ($reg=mysqli_fetch_array($registros)) {
	    	echo "Codigo: ".$reg['codigo_alu']. "<br>";
	    	echo "Nombre: ".$reg['nombre_alu']. "<br>";
	    	echo "Correo: ".$reg['correo_alu']. "<br>";
	    	echo "Curso: ";

	    	switch ($reg['codigo_cur_alu']) {
	    		case 1: echo "Java";
	    			break;
	    		case 2: echo "JS";
	    			break;
	    		case 3: echo "Python";
	    			break;
	    	}
	    	echo "<br>";
	    	echo "<br>";
	    }

	    mysqli_close($conexion);
	?>

</body>
</html>