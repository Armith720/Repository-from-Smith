<!DOCTYPE html>
<html>
<head>
	<title>Conexion con base1</title>
</head>
<body>
	<?php
	$conexion=mysqli_connect("localhost","root","","base1") or 
	    die("problemas con la conexion");


	    mysqli_query($conexion, "insert into alumnos(nombre_alu,correo_alu,codigo_cur_alu) values 
	    ('$_REQUEST[nombre]','$_REQUEST[correo]','$_REQUEST[codigo_cur_alu]')") or die("problemas en el select ".mysqli_error($conexion));

	    mysqli_close($conexion);

	    echo "El alumno fue dado de alta";
	?>

</body>
</html>