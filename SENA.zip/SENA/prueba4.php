<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	$dia=24;
	$sueldo= 758.42;
	$nombre= "Juan";
	$exite= true;

	echo "Variable integer: ";
	echo $dia;
	echo "<br>";
	echo "Variable double: ";
	echo $sueldo;
	echo "<br>";
	echo "Variable string: ";
	echo $nombre;
	echo "<br>";
	echo "Variable boolean: ";
	echo $exite;
	?>
</body>
</html>