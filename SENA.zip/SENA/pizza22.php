<!DOCTYPE html>
<html>
<head>
	<title>Pizza</title>
</head>
<body>
	<?php
	$ar = fopen("pedidos.txt", "r") or 
	die("No se pudo encontrar el archivo");


	while (!feof($ar)) {
		$linea = fgets($ar);
		$lieasalto = n12br($linea);
		echo $lineasalto;
	}

	fclose($ar);




	?>

</body>
</html>