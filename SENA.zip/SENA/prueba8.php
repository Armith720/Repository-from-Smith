<!DOCTYPE html>
<html>
<head>
	<title>Prueba 8</title>
</head>
<body>
	<?php
	$valor=rand(1,3);
	  echo "El nuemro es $valor<br>";

	  if ($valor==3) {
	  	echo "El valor en castellano es tres";
	  } else {
	  	if ($valor==2) {
	  		echo "El valor en castellano es dos";
	  	} else {
	  		if ($valor==1) {
	  			echo "El valor en castellano es uno";
	  		}
	  	}
	  }
	?>
</body>
</html>