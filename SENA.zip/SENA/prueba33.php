<html>
<head>	
    <title>Prueba 33</title>
</head>
<body>
<form action="pagina33.php" method="post">
	Ingrese el mail del alumno:
<input type="text" name="mail"><br>
<input type="submit" value="buscar">
</form>
</body>
</html>