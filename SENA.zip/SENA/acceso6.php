<!DOCTYPE html>
<html>
<head>
	<title>Conexion con base1</title>
</head>
<body>
	<?php
	$conexion=mysqli_connect("localhost","root","","base1") or 
	    die("problemas con la conexion");


	    $registros = mysqli_query($conexion, "select codigo_curs from cursos where nombre_curs='$_REQUEST[name]'") or die("problemas en el select ".mysqli_error($conexion));


	    if($reg=mysqli_fetch_array($registros)) {
	    	mysqli_query($conexion, "delete from cursos where nombre_curs='$_REQUEST[name]'") or die("problemas en el select ".mysqli_error($conexion));

	    	echo "Curso eliminado correctamente.";

	    } else {
	    	echo "No se encuentra ningun curso con ese nombre <br><br>";
	    }

	    mysqli_close($conexion);
	?>

	<a href="accesobase6.html">Regresar</a>

</body>
</html>