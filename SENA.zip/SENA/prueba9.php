<!DOCTYPE html>
<html>
<head>
	<title>Prueba 9</title>
</head>
<body>
	<?php
	for ($f=1; $f<=100; $f++) { 
		echo $f;

		echo "<br>";
	}
	?>
</body>
</html>