package stadyPage;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class pruebaFiguras {
    
    public static void main(String[] args) {
        String entrada = JOptionPane.showInputDialog("Escriba 1 para dibujar rectangulos\n" + "Escriba 2 para dibujar ovalos\n" + "Escriba 3 para mostrar el reto");

        int opcion = Integer.parseInt( entrada );

        figuras panel = new figuras(opcion);

        JFrame aplicacion = new JFrame();

        aplicacion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        aplicacion.add(panel);
        aplicacion.setSize( 300, 300);
        aplicacion.setVisible( true );
    }
}
