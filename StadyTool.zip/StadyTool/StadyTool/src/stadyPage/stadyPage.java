package stadyPage;
import java.util.Scanner;

public class stadyPage  {


    public static void main(String[] args) throws Exception {
        
        try (Scanner scanterm = new Scanner(System.in)) {
            String termvar;
            System.out.println("Enter a study term");
            termvar = scanterm.nextLine();

            try (Scanner scandef = new Scanner(System.in)) {
                String termdef;
                System.out.println("Enter a definition");
                termdef = scandef.nextLine();

                System.out.println(termvar + ": " + termdef);
            }
        }
        
    }
    
}
