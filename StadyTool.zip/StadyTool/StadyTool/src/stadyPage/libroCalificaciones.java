package stadyPage;

public class libroCalificaciones  {

    public void  mostrarMensaje() {
        System.out.println("Bienvenido al Libro de Calificaciones.");
    } 
}
