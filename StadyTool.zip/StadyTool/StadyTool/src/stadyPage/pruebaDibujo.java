package stadyPage; 
import javax.swing.JFrame;

public class pruebaDibujo {
    public static void main(String [] args ) {
        
        
        dibujo panel = new dibujo();

        
        JFrame aplicacion = new JFrame();

        
        aplicacion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        aplicacion.add(panel);
        aplicacion.setSize(250, 250);
        aplicacion.setVisible(true);
    }
    
}
