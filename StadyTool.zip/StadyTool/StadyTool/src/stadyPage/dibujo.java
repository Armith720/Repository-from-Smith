package stadyPage;

import java.awt.Graphics;
import javax.swing.JPanel;

public class dibujo extends JPanel{
    
    public void paintComponent(Graphics g){
        
        super.paintComponent(g);

        int anchura = getWidth(); 
        int altura = getHeight(); 


        g.drawLine(15, 200, 0, 0);
        g.drawLine(25, 190, 0, 0);
        g.drawLine(35, 180, 0, 0);
        g.drawLine(45, 170, 0, 0);
        g.drawLine(55, 160, 0, 0);
        g.drawLine(70, 150, 0, 0);
        g.drawLine(80, 140, 0, 0);
        g.drawLine(90, 130, 0, 0);
        g.drawLine(100, 120, 0, 0);
        g.drawLine(110, 110, 0, 0);
        g.drawLine(120, 100, 0, 0);
        g.drawLine(130, 95, 0, 0);
        g.drawLine(140, 85, 0, 0);
        g.drawLine(150, 75, 0, 0);
        g.drawLine(160, 65, 0, 0);
        g.drawLine(175, 55, 0, 0);
        g.drawLine(185, 45, 0, 0);
        g.drawLine(195, 35, 0, 0);
        g.drawLine(205, 25, 0, 0);
        g.drawLine(215, 15, 0, 0);
        
        g.drawLine(200, 0, 0, 15);
        g.drawLine(190, 0, 0, 25);
        g.drawLine(180, 0, 0, 35);
        g.drawLine(170, 0, 0, 45);
        g.drawLine(160, 0, 0, 55);
        g.drawLine(150, 0, 0, 70);
        g.drawLine(140, 0,0, 80);
        g.drawLine(130, altura, anchura, 90);
        g.drawLine(120, altura, anchura, 100);
        g.drawLine(110, altura, anchura, 110);
        g.drawLine(100, altura, anchura, 120);
        g.drawLine(95, altura, anchura, 130);
        g.drawLine(85, altura, anchura, 140);
        g.drawLine(75, altura, anchura, 150);
        g.drawLine(65, altura, anchura, 160);
        g.drawLine(55, altura, anchura, 175);
        g.drawLine(45, altura, anchura, 185);
        g.drawLine(35, altura, anchura, 195);
        g.drawLine(25, altura, anchura, 205);
        g.drawLine(15, altura, anchura, 215);
        
        g.drawLine(0, 0, anchura, altura);
        g.drawLine(0, altura, anchura, 0);
        g.drawLine(15, altura, anchura, 15);
        g.drawLine(25, altura, anchura, 25);
        g.drawLine(35, altura, anchura, 35);
        g.drawLine(45, altura, anchura, 45);
        g.drawLine(55, altura, anchura, 55);
        g.drawLine(65, altura, anchura, 65);
        g.drawLine(70, altura, anchura, 75);
        g.drawLine(80, altura, anchura, 85);
        g.drawLine(90, altura, anchura, 95);
        g.drawLine(100, altura, anchura, 100);
        g.drawLine(110, altura, anchura, 110);
        g.drawLine(120, altura, anchura, 120);
        g.drawLine(130, altura, anchura, 130);
        g.drawLine(140, altura, anchura, 140);
        g.drawLine(150, altura, anchura, 150);
        g.drawLine(160, altura, anchura, 160);
        g.drawLine(175, altura, anchura, 170);
        g.drawLine(185, altura, anchura, 180);
        g.drawLine(195, altura, anchura, 190);
        g.drawLine(205, altura, anchura, 200);



        g.drawLine(0, anchura, 0,  altura);
        

       
        
    }
}
