package stadyPage;

public class libroCalificaciones2 {

    private String nombreDelCurso;

    public void establecerNombreDelCurso(String nombre) {
        nombreDelCurso = nombre;
    }
    
    public String obtenerNombreDelCurso() { 
        return nombreDelCurso;
    }

    public void mostrarMensaje() {
        System.out.printf("Bienvenido al Libro de calificaciones para\n%s\n", obtenerNombreDelCurso());
    }
}
