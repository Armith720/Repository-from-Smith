package stadyPage;
import java.util.Scanner;

public class pruebaLibroCalificaciones1 {

    public static void main(String [] args) {

        try (Scanner entrada = new Scanner(System.in)) {
            libroCalificaciones1 miLibroCalificaciones = new libroCalificaciones1();


            System.out.println("Escriba el nombre del curso");
            String nombreDelCurso = entrada.nextLine();
            System.out.println();

            miLibroCalificaciones.mostrarMensaje(nombreDelCurso);
        }

    }
    
}
