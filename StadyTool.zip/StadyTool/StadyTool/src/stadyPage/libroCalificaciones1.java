package stadyPage;

public class libroCalificaciones1 {

    public void mostrarMensaje(String nombreDelCurso) {

        System.out.printf("Bienvenido al Libro de calificaciones\n%s\n", nombreDelCurso);

    }
    
}
