package stadyPage;

public class pruebaLibroCalificaciones3 {
    public static void main(String [] args) {


        

        libroCalificaciones3 miLibroCalificaciones2 = new libroCalificaciones3("CS102 EStructuras de datos de Java");

        libroCalificaciones3 miLibroCalificaciones = new libroCalificaciones3("CS101 Intruduccion a la programacion en Java");
        



        System.out.printf("El nombre del curso de libro de calificaciones: %s\n",miLibroCalificaciones.obtenerNombreDelCurso());
        System.out.printf("El nombre del curso de libro de calificaciones es: %s\n",miLibroCalificaciones2.obtenerNombreDelCurso());
    }
}
