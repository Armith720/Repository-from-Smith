package stadyPage;

public class persona2 {


    public static void main(String [] args) {
        persona p1 = new persona("Smith", 20);


        p1.mostrarDatos();


    }
}
