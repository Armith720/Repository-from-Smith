 package stadyPage;

public class libroCalificaciones3 {
 private static String nombreDelCurso;

    public libroCalificaciones3 (String nombre) {
        nombreDelCurso = nombre;
    }
    

    public void establecerNombreDelCurso(String nombre) {
        nombreDelCurso = nombre;
    }

    public String obtenerNombreDelCurso() {
        return nombreDelCurso;   
    }  

    public void  mostrarMensaje() {
        System.out.printf("Bienvenido al curso\n%s\n",obtenerNombreDelCurso());
    }
}