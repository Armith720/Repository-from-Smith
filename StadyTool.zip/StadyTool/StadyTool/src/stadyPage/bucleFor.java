package stadyPage;

public class bucleFor {
    public static void main(String [] args) {
        
        int total=0;

        for(int num=2; num<=10; num+=2){
            total += num;
   
        }
        System.out.println("La suma es:  " + total);
    }
}
