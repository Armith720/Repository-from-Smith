package stadyPage;

public class persona {

    String nombre;
    int edad; 

public  persona(String _nombre, int _edad) {
    nombre = _nombre;
    edad = _edad;
}
public void mostrarDatos() {
    System.out.println("El nombre es: " + nombre);
    System.out.println("La edad es: " + edad);
}





}

