package stadyPage;

public class pruebaLibroCalificaciones {

   
    public static void main(String [] args ) {
        libroCalificaciones miLibroCalificaciones = new libroCalificaciones();

        miLibroCalificaciones.mostrarMensaje();
    }
} 