package stadyPage;
import java.util.Scanner;

public class galones  { 


    public static void main(String[] args) throws Exception {

        
        double resultado;
        
        try (Scanner scanterm = new Scanner(System.in)) {
            System.out.println("Ingrese los galones deseados");
            int num1 = scanterm.nextInt();

            resultado = num1 * 3.785;
 
            System.out.println(num1 + " galones son " + resultado + " litros");
        }
        
    }
    
}
