package stadyPage;

public class ejercicioBreak {
    public static void main(String[] args) {
        int cuenta;

        for(cuenta = 1; cuenta <= 10; cuenta++){
            if ( cuenta==5){
                break;
            }
            System.out.printf(" " + cuenta);
        }
        System.out.printf("\nSalio del ciclo en la cuneta = " + cuenta);
    }
        
    
}
