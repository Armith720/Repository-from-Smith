package stadyPage;

public class ejercicioContinue {
    
    public static void main(String[] args) {
        int cuenta;

        for(cuenta = 1; cuenta <= 10; cuenta++){
            if ( cuenta==5){
                continue;
            }
            System.out.printf(" " + cuenta);
        }
        System.out.printf("\nSe uso continue para omitir el numero 5");
    }
}
