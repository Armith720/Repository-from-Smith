package stadyPage;
import java.awt.Graphics;
import javax.swing.JPanel;

public class figuras extends JPanel {
    private int opcion;

    public figuras( int opcionUsuario){

        opcion = opcionUsuario;
    }


    public void paintComponent(Graphics g){
        super.paintComponent(g);

        int x1 = 117;
        int y1 = 105;
        int y2 = 50;
        for (int i = 0; i < 10; i++){
            switch( opcion ){
                case 1:
                g.drawRect(10 + i * 10, 10 + i * 10, 50 + i * 10, 50 + i * 10);
                break;

                case 2:
                g.drawOval(10 + i * 10, 10 + i * 10, 50 + i * 10, 50 + i * 10);
                break;

                case 3:
                g.drawOval(x1,y1,y2,y2);
                x1=x1-5;
                y1=y1-5; 
                y2=y2+10;
                break;
            }
        }
    }
}
