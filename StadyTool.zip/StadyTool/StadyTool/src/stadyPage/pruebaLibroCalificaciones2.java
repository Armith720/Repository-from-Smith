package stadyPage;
import java.util.Scanner;

public class pruebaLibroCalificaciones2 {

    public static void main(String [] args) {
        

    try (Scanner entrada = new Scanner(System.in)) {
        libroCalificaciones2 mLibroCalificaciones2 = new libroCalificaciones2();

        System.out.printf("El nombre inicial del curso es: %s\n\n", mLibroCalificaciones2.obtenerNombreDelCurso());

        System.out.println("Escriba el nombre del curso: ");
        String elNombre = entrada.nextLine();
        mLibroCalificaciones2.establecerNombreDelCurso(elNombre);
        System.out.println();

        mLibroCalificaciones2.mostrarMensaje();
    }
  }
}
